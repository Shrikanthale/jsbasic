

var Celcius=12
var Fahrenheit

Fahrenheit = (Celcius*1.8)+32

console.log(`Farhenheit is ${Fahrenheit.toFixed(2)}`)