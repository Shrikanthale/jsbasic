

var N=18;

if(N<0)
{
    console.log("Error")
    return
}
else if(N==0)
{
    console.log("0")
    return
}
else 
{
var i , sequence;
for(i=1;i<=N;i++)
{
    sequence=i*i
}
}
console.log(sequence)