
let N=2

cube=N*N*N

console.log(`The cube of ${N} is ${cube}.` )