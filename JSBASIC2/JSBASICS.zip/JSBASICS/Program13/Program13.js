

var n=5
var s=0

for(i=1;i<=n;i++)
{
    s=(i*i)+i
}

console.log(`The series of ${n} is ${s}`)

