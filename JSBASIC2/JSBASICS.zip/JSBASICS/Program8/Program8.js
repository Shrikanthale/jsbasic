

var A="Lorem Ipsum";
console.log(A.replace(/\s/g,''))
var string = A.replace(/\s/g,'')
console.log(string.length)