

let a=20;

Area=1/4*(1.732*a*a)  //since the value of √3 is 1.732

console.log(`The area of equilateral triangle of ${a} is ${Area.toFixed(2)}`)
