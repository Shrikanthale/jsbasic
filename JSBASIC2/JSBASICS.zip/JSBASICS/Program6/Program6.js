

var N = 10
var sum=0

for(let i =1;i<=N;i++)
{
    sum=sum+i
}
console.log(`Sum of number is ${sum}.`)